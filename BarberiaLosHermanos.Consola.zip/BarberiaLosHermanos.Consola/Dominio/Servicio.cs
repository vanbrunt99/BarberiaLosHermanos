﻿namespace BarberiaLosHermanos.Consola.Dominio
{
    // Representa un servicio de la barbería (ej. Corte, Barba) con su precio.
    public class Servicio
    {
        // Nombre del servicio mostrado al usuario.
        public string Nombre { get; }

        // Precio actual del servicio (decimal para dinero).
        public decimal Precio { get; }

        // Constructor con validaciones mínimas (Clean Code: fail-fast).
        public Servicio(string nombre, decimal precio)
        {
            if (string.IsNullOrWhiteSpace(nombre))
                throw new ArgumentException("El nombre del servicio es obligatorio.", nameof(nombre));

            if (precio < 0)
                throw new ArgumentOutOfRangeException(nameof(precio), "El precio no puede ser negativo.");

            Nombre = nombre.Trim();
            Precio = precio;
        }

        // Override para mostrarlo bonito en listas.
        public override string ToString() => $"{Nombre} - ₡{Precio:N2}";
    }
}

