﻿namespace BarberiaLosHermanos.Consola.Dominio
{
    // Validador de reglas de negocio de Cita (SRP: separa validaciones).
    public static class ValidadorCitas
    {
        // Valida que la fecha/hora no sea pasada ni exceda 7 días de anticipación.
        public static void ValidarFecha(DateTime fechaHora, DateTime? ahora = null)
        {
            // Permite inyectar "ahora" para pruebas. Si no viene, usa DateTime.Now.
            var clock = ahora ?? DateTime.Now;

            // No se permiten fechas pasadas (comparación a minuto exacto).
            if (fechaHora <= clock)
                throw new ArgumentException("No se permiten citas en fechas/horas pasadas.");

            // Límite máximo de anticipación: 7 días calendario.
            if (fechaHora > clock.AddDays(7))
                throw new ArgumentException("Solo se puede agendar con un máximo de 7 días de anticipación.");
        }
    }
}

