﻿namespace BarberiaLosHermanos.Consola.Dominio
{
    // Cliente de la barbería: hereda de Persona
    public class Cliente : Persona
    {
        // Constructor público que delega a la clase base Persona.
        public Cliente(string nombre, string? telefono, string? correo)
            : base(nombre, telefono, correo) { }

        
        public override string Resumen()
        {
            return $"Nombre: {Nombre} | Tel: {Telefono ?? "-"} | Correo: {Correo ?? "-"}";
        }
    }
}


