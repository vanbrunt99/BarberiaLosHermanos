﻿namespace BarberiaLosHermanos.Consola.Dominio
{
    // Entidad de dominio: una cita con cliente, servicio y fecha/hora.
    public class Cita
    {
        // Identificador legible para cancelar/consultar.
        public string Id { get; }

        // Cliente asociado a la cita (requerido).
        public Cliente Cliente { get; }

        // Servicio a realizar (requerido).
        public Servicio Servicio { get; }

        // Momento exacto de la cita.
        public DateTime FechaHora { get; }

        // Constructor aplica reglas de negocio vía ValidadorCitas.
        public Cita(Cliente cliente, Servicio servicio, DateTime fechaHora, Func<string>? generadorId = null, DateTime? ahora = null)
        {
            // Validaciones de referencias nulas (fail-fast).
            Cliente = cliente ?? throw new ArgumentNullException(nameof(cliente));
            Servicio = servicio ?? throw new ArgumentNullException(nameof(servicio));

            // Valida reglas temporales (no pasado / máximo 7 días).
            ValidadorCitas.ValidarFecha(fechaHora, ahora);

            // Asignación de la fecha/hora validada.
            FechaHora = fechaHora;

            // Genera un ID corto y legible (8 chars del GUID) o usa uno inyectado (pruebas).
            Id = (generadorId?.Invoke() ?? Guid.NewGuid().ToString("N")[..8]).ToUpperInvariant();
        }

        // Representación amigable para listados.
        public override string ToString()
            => $"[{Id}] {FechaHora:g} — {Cliente.Nombre} — {Servicio.Nombre} (₡{Servicio.Precio:N2})";
    }
}
