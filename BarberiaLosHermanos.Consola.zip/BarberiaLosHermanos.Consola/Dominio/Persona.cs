﻿namespace BarberiaLosHermanos.Consola.Dominio
{
    // Clase base abstracta: modela datos comunes de una persona.
    public abstract class Persona
    {
        // Nombre completo del contacto (requerido).
        public string Nombre { get; protected set; }

        // Teléfono de contacto (opcional pero útil para recordatorios).
        public string? Telefono { get; protected set; }

        // Correo electrónico (Opcional; futuro envío de promociones).
        public string? Correo { get; protected set; }

        // Constructor protegido: obliga a usar constructores de clases hijas.
        protected Persona(string nombre, string? telefono, string? correo)
        {
            // Validación simple: nombre no puede ser nulo ni vacío.
            if (string.IsNullOrWhiteSpace(nombre))
                throw new ArgumentException("El nombre es obligatorio.", nameof(nombre));

            // Asignaciones inmutables hacia afuera (solo set interno).
            Nombre = nombre.Trim();
            Telefono = string.IsNullOrWhiteSpace(telefono) ? null : telefono.Trim();
            Correo = string.IsNullOrWhiteSpace(correo) ? null : correo.Trim();
        }

        // Método virtual para mostrar un resumen de la persona.
        // Permite polimorfismo en las clases derivadas.
        public virtual string Resumen()
        {
            return $"Nombre: {Nombre}";
        }
    }
}


